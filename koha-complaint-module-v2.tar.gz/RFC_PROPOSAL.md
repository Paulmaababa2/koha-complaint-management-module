# RFC: Dedicated Issue Tracking and Resolution Module for Koha ILS
# "Complaint Management and User Grievance Redressal"

---

## The Problem Koha Does Not Solve Today

Koha is a library management software. It manages catalogues, circulation, patrons, acquisitions, and serials. But it does **not** manage the **problems that arise while using these services**.

Every management software — whether corporate ERP, hospital management, or banking — has a **dedicated glitch/issue portal** where users raise problems and the right person resolves them. This is standard practice:

| Software Domain | Issue Portal |
|----------------|-------------|
| Corporate IT | ServiceNow, Jira Service Desk |
| Banking | Customer grievance cell |
| Hospital | Patient complaint redressal |
| E-commerce | Order issue tracking |
| Government | Public grievance portal (CPGRAMS) |
| **Library (Koha)** | **Nothing. Zero. No dedicated module.** |

Koha has "Purchase Suggestions" (patron wants a new book), "OPAC Problem Reports" (website bug), and "Catalogue Concerns" (metadata error). But **none of these** handle the real-world problems patrons face every day:

- "I returned the book but I am still being charged a fine"
- "My hold has been pending for 3 weeks with no response"
- "The library Wi-Fi has not worked for 5 days"
- "The staff member was unhelpful and rude"
- "I cannot access e-journals from home"
- "My membership was wrongly deactivated"

Today, these problems are handled through:
- Verbal complaints at the desk (no record)
- Email to the librarian (no tracking)
- Paper complaint register (no assignment, no SLA, no closure)
- WhatsApp messages (informal, no audit trail)

**Result:** Problems are lost. Nobody is assigned. Nobody is accountable. There is no data to improve services. Libraries cannot demonstrate quality management to accreditation bodies (NAAC, UGC, ISO).

---

## What This Module Does

This module adds a **dedicated Issue Tracking and Resolution System** to Koha — a structured portal where:

### For Patrons (via OPAC):
1. **Register** a complaint/issue with a specific category, description, and priority
2. **Receive** a unique tracking ID (e.g., CMP-2026-0047)
3. **Track** the status in real time from their OPAC account
4. **Get notified** via email/SMS when status changes
5. **Rate** satisfaction after resolution
6. **View** the resolution remarks (so they know what was done)

### For Library Staff (via Staff Client):
1. **View** all incoming issues in a centralised dashboard
2. **Assign** each issue to the correct staff member (circulation issue → circulation staff, IT issue → IT team)
3. **Track** SLA deadlines (critical: 24h, high: 48h, medium: 5 days, low: 10 days)
4. **Add** internal staff notes (not visible to patron) for investigation
5. **Escalate** to department head or chief librarian if unresolved
6. **Resolve** with public remarks (visible to patron — explains what was done)
7. **Close** with documented resolution for future reference
8. **Report** on trends — which categories have most issues, which staff resolves fastest, what is the SLA compliance rate

### The Critical Distinction from Existing Koha Features:

| Feature | Purpose | This Module |
|---------|---------|------------|
| Purchase Suggestions | "Please buy this book" | "My fine is wrong, fix it" |
| OPAC Problem Reports | "The website has a broken link" | "The circulation desk charged me incorrectly" |
| Catalogue Concerns | "This MARC record has wrong author" | "I cannot access e-journals from home" |
| **Complaint Management** | **"I have a problem with library service — assign someone, fix it, and tell me what you did"** | **Full lifecycle: Register → Assign → Investigate → Resolve → Close → Report** |

This module is about **service delivery problems and their resolution** — not about suggestions, not about website bugs, not about catalogue errors. It is about **holding the library accountable** to its patrons through a transparent, trackable process.

---

## How It Fits Into Koha

### On the Home Page (Staff Client):
The module appears as a new tile on the Koha staff client home page, placed **after E-resource management** as the last module:

```
Circulation          | Cataloging
Patrons              | Serials
Advanced search      | Acquisitions
Item search          | Reports
Lists                | Tools
Authorities          | Administration
E-resource management| Complaint management  ← NEW
```

### In the OPAC (Patron Account):
A new section appears in the patron's "Your Account" sidebar:

```
Your account
├── Checked out (3)
├── Holds (1)
├── Charges
├── Purchase suggestions
├── My complaints (new)      ← NEW
├── Submit new complaint     ← NEW
└── Track complaint          ← NEW
```

---

## Complaint Lifecycle (Workflow)

```
PATRON registers complaint via OPAC
         ↓
System generates unique ID (CMP-2026-XXXX)
System sends acknowledgement email/SMS
         ↓
Staff sees complaint in dashboard
Staff ASSIGNS to correct person based on category
         ↓
Assigned staff INVESTIGATES
Adds internal notes (staff-only)
         ↓
    ┌─── Resolved? ───┐
    │                  │
   YES                NO
    │                  │
Staff adds            Staff ESCALATES
resolution            to supervisor
remarks               ↓
    │            Supervisor resolves
    ↓                  │
Patron NOTIFIED ←──────┘
of resolution
    ↓
Patron rates satisfaction (1-5 stars)
    ↓
Complaint CLOSED
    ↓
Resolution archived for reporting
and future prevention
```

---

## Categories (Configurable by Library)

Each library can define its own categories. Default set:

| # | Category | Example Issues | Default SLA |
|---|----------|---------------|-------------|
| 1 | Circulation services | Wrong fines, hold delays, renewal problems | 2 days |
| 2 | Cataloguing & metadata | Wrong records, missing entries | 5 days |
| 3 | OPAC & discovery | Search failures, display errors | 3 days |
| 4 | Staff conduct | Unhelpful behaviour, service quality | 2 days |
| 5 | Infrastructure & facilities | Wi-Fi, seating, noise, AC, lighting | 5 days |
| 6 | Collection development | Missing titles, outdated resources | 10 days |
| 7 | Digital resources & e-access | E-journals, databases, remote login | 2 days |
| 8 | Membership & accounts | Registration issues, account errors | 3 days |
| 9 | Interlibrary loan (ILL) | ILL delays, wrong items | 5 days |
| 10 | Accessibility & inclusion | Physical or digital accessibility | 5 days |
| 11 | General / Other | Anything not covered above | 5 days |

---

## Database Schema

```sql
-- ============================================================
-- TABLE 1: complaint_categories
-- Configurable categories with SLA defaults
-- ============================================================
CREATE TABLE complaint_categories (
    category_id   INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    description   TEXT,
    sla_days      INT NOT NULL DEFAULT 5,
    is_active     TINYINT(1) NOT NULL DEFAULT 1,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 2: complaints
-- Core table — one row per registered complaint
-- ============================================================
CREATE TABLE complaints (
    complaint_id      INT AUTO_INCREMENT PRIMARY KEY,
    complaint_code    VARCHAR(20) NOT NULL UNIQUE,
    -- Who raised it
    borrowernumber    INT DEFAULT NULL,          -- NULL if guest
    guest_name        VARCHAR(200) DEFAULT NULL,
    guest_email       VARCHAR(200) DEFAULT NULL,
    -- Classification
    category_id       INT NOT NULL,
    priority          ENUM('critical','high','medium','low') NOT NULL DEFAULT 'medium',
    -- Status workflow
    status            ENUM('open','acknowledged','assigned','under_review',
                           'escalated','resolved','closed') NOT NULL DEFAULT 'open',
    -- Content
    subject           VARCHAR(255) NOT NULL,
    description       TEXT NOT NULL,
    attachment_path   VARCHAR(500) DEFAULT NULL,
    -- Assignment
    branchcode        VARCHAR(10) DEFAULT NULL,
    assigned_to       INT DEFAULT NULL,
    escalated_to      INT DEFAULT NULL,
    -- Resolution
    resolution_notes  TEXT DEFAULT NULL,         -- Visible to patron
    resolution_remarks TEXT DEFAULT NULL,        -- Public remarks for future prevention
    -- Satisfaction
    satisfaction_rating TINYINT DEFAULT NULL,    -- 1 to 5 stars
    satisfaction_comment TEXT DEFAULT NULL,
    -- SLA
    sla_deadline      DATETIME DEFAULT NULL,
    -- Timestamps
    created_at        DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    acknowledged_at   DATETIME DEFAULT NULL,
    assigned_at       DATETIME DEFAULT NULL,
    resolved_at       DATETIME DEFAULT NULL,
    closed_at         DATETIME DEFAULT NULL,
    -- Foreign keys
    CONSTRAINT fk_complaint_category
        FOREIGN KEY (category_id) REFERENCES complaint_categories(category_id),
    CONSTRAINT fk_complaint_patron
        FOREIGN KEY (borrowernumber) REFERENCES borrowers(borrowernumber)
        ON DELETE SET NULL,
    -- Indexes
    INDEX idx_status (status),
    INDEX idx_category (category_id),
    INDEX idx_priority (priority),
    INDEX idx_assigned (assigned_to),
    INDEX idx_branch (branchcode),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 3: complaint_activity_log
-- Full audit trail of every action taken
-- ============================================================
CREATE TABLE complaint_activity_log (
    log_id          INT AUTO_INCREMENT PRIMARY KEY,
    complaint_id    INT NOT NULL,
    action          VARCHAR(50) NOT NULL,       -- 'status_changed', 'assigned', 'note_added', etc.
    performed_by    INT DEFAULT NULL,           -- borrowernumber of staff
    old_value       TEXT DEFAULT NULL,
    new_value       TEXT DEFAULT NULL,
    notes           TEXT DEFAULT NULL,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_complaint
        FOREIGN KEY (complaint_id) REFERENCES complaints(complaint_id)
        ON DELETE CASCADE,
    INDEX idx_log_complaint (complaint_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 4: complaint_notes
-- Staff internal notes (not visible to patron)
-- ============================================================
CREATE TABLE complaint_notes (
    note_id       INT AUTO_INCREMENT PRIMARY KEY,
    complaint_id  INT NOT NULL,
    staff_id      INT NOT NULL,
    note_text     TEXT NOT NULL,
    is_internal   TINYINT(1) NOT NULL DEFAULT 1,  -- 1=staff only, 0=visible to patron
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_note_complaint
        FOREIGN KEY (complaint_id) REFERENCES complaints(complaint_id)
        ON DELETE CASCADE,
    INDEX idx_note_complaint (complaint_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- DEFAULT DATA: Insert default categories
-- ============================================================
INSERT INTO complaint_categories (name, description, sla_days) VALUES
('Circulation services', 'Fines, holds, renewals, lost item disputes', 2),
('Cataloguing & metadata', 'Wrong records, missing entries, duplicate records', 5),
('OPAC & discovery', 'Search failures, display errors, broken links', 3),
('Staff conduct', 'Behaviour, service quality, unhelpful response', 2),
('Infrastructure & facilities', 'Wi-Fi, seating, noise, AC, lighting, washrooms', 5),
('Collection development', 'Missing titles, outdated resources, gaps', 10),
('Digital resources & e-access', 'E-journals, databases, remote access, proxy', 2),
('Membership & accounts', 'Registration, account errors, card issues', 3),
('Interlibrary loan (ILL)', 'ILL delays, wrong items received', 5),
('Accessibility & inclusion', 'Physical or digital accessibility barriers', 5),
('General / Other', 'Uncategorised complaints', 5);
```

---

## New System Preferences

| Preference | Type | Default | Description |
|-----------|------|---------|-------------|
| ComplaintsEnabled | YesNo | 0 | Master switch to enable/disable the module |
| ComplaintAllowGuest | YesNo | 0 | Allow non-logged-in users to submit |
| ComplaintSLACritical | Integer | 1 | SLA days for critical priority |
| ComplaintSLAHigh | Integer | 2 | SLA days for high priority |
| ComplaintSLAMedium | Integer | 5 | SLA days for medium priority |
| ComplaintSLALow | Integer | 10 | SLA days for low priority |
| ComplaintEmailNotify | YesNo | 1 | Send email on status change |
| ComplaintSMSNotify | YesNo | 0 | Send SMS on status change |
| ComplaintRequireSatisfaction | YesNo | 1 | Require rating before closing |
| ComplaintMaxAttachmentMB | Integer | 5 | Max file upload size |
| ComplaintAutoAcknowledge | YesNo | 1 | Auto-acknowledge on submission |

---

## New Notice Templates (Letters)

| Code | Trigger | Content |
|------|---------|---------|
| COMPLAINT_REGISTERED | Patron submits | "Your complaint CMP-XXXX has been registered" |
| COMPLAINT_ACKNOWLEDGED | System acknowledges | "Your complaint has been acknowledged" |
| COMPLAINT_ASSIGNED | Staff assigns | "Your complaint has been assigned to [name]" |
| COMPLAINT_UPDATED | Status changes | "Your complaint status is now: [status]" |
| COMPLAINT_RESOLVED | Staff resolves | "Your complaint has been resolved: [remarks]" |
| COMPLAINT_CLOSED | Staff closes | "Your complaint is closed. Please rate." |
| COMPLAINT_SLA_WARNING | SLA approaching | Alert to assigned staff |
| COMPLAINT_SLA_BREACH | SLA breached | Alert to supervisor |

---

## REST API Endpoints

```
# Patron-facing (OPAC)
POST   /api/v1/complaints                        Submit new complaint
GET    /api/v1/complaints?borrowernumber={id}     List patron's complaints
GET    /api/v1/complaints/{complaint_id}          View complaint details
POST   /api/v1/complaints/{id}/satisfaction       Submit satisfaction rating

# Staff-facing (Intranet)
GET    /api/v1/complaints                         List all (with filters)
PUT    /api/v1/complaints/{id}                    Update complaint
PATCH  /api/v1/complaints/{id}/status             Change status
PATCH  /api/v1/complaints/{id}/assign             Assign to staff
PATCH  /api/v1/complaints/{id}/escalate           Escalate
PATCH  /api/v1/complaints/{id}/resolve            Resolve with remarks
POST   /api/v1/complaints/{id}/notes              Add internal note
GET    /api/v1/complaints/{id}/activity            View activity log

# Admin
GET    /api/v1/complaints/categories              List categories
POST   /api/v1/complaints/categories              Add category
PUT    /api/v1/complaints/categories/{id}         Edit category
GET    /api/v1/complaints/reports/summary          Dashboard stats
GET    /api/v1/complaints/reports/staff            Staff performance
GET    /api/v1/complaints/reports/trends           Monthly trends
```

---

## Why This Matters

### For Libraries:
- **Accountability**: Every issue has an owner, a deadline, and a resolution
- **Data**: Know which services have the most problems and fix the root cause
- **Accreditation**: NAAC, UGC, ISO 9001 all require documented complaint management
- **Staff performance**: Measure who resolves issues fastest and best

### For Patrons:
- **Voice**: A formal channel to report real problems (not just suggestions)
- **Transparency**: See exactly who is handling their issue and when it will be resolved
- **Trust**: Know that the library takes their problems seriously
- **Closure**: Get a documented resolution, not just a verbal "we'll look into it"

### For the Koha Community:
- **First of its kind**: No open-source ILS has a dedicated complaint management module
- **Differentiator**: Makes Koha more complete than Alma, Evergreen, or FOLIO
- **Service quality**: Moves Koha from a collection management tool to a full service management platform

---

## Implementation Plan

| Phase | Weeks | Deliverables |
|-------|-------|-------------|
| 1. Database & API | 4 | Schema, migrations, REST endpoints, unit tests |
| 2. Staff Interface | 3 | Dashboard, complaint list, manage/resolve, categories |
| 3. OPAC Portal | 3 | Submit form, tracking page, satisfaction rating |
| 4. Notifications | 2 | Email/SMS templates, SLA alerts, cron jobs |
| 5. Reports | 2 | Dashboard analytics, CSV/PDF export, SQL reports |
| 6. Testing & QA | 2 | Community testing, sign-offs, documentation |

**Total: 16 weeks**

---

## Compatibility

- Koha 24.05+ (modern REST API, Bootstrap 5 staff client)
- MariaDB 10.5+ / MySQL 8.0+
- Can be implemented as a **Koha plugin** first, then merged into core after community adoption
- GPL-3.0-or-later (same as Koha)

---

**This RFC is submitted for community discussion. Comments welcome on Bugzilla and the koha-devel mailing list.**

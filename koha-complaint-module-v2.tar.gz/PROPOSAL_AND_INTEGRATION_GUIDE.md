# Koha Complaint Management – Proposal & Integration Guide

## 1. Whom to Contact and Where to Go

### A. Bugzilla (Primary — mandatory first step)
**URL:** https://bugs.koha-community.org/bugzilla3/enter_bug.cgi

This is the single source of truth for all Koha enhancements. Every new feature
must have a Bugzilla ticket. Steps:

1. Create a free account at https://bugs.koha-community.org/bugzilla3/createaccount.cgi
2. Click "File a Bug" → choose product **Koha**, component **Tools** (or New Components)
3. Set Severity = **enhancement**
4. Title: `[NEW MODULE] Complaint and Glitch Management`
5. Describe the module fully (paste your RFC summary)
6. Note your bug number — it becomes your branch name (e.g. `bug_XXXXX`)

---

### B. Koha Wiki – RFC Page (Second mandatory step)
**URL:** https://wiki.koha-community.org/wiki/RFC_Complaints_Module  ← create this page

Template to paste on the wiki:

```
{{RFC
|title=Complaint and Glitch Management Module
|date=2025-01-01
|module=Tools / Patron Services
|sponsor=Your Institution Name
|developer=Your Name
|bug=BUGZILLA_NUMBER
|desc=
A dedicated module for library staff and patrons to raise operational
glitches and complaints, assign them to the correct staff member,
track resolution, and append prevention notes to patron records.
Prevents recurrence and replaces ad-hoc email/feedback workarounds.
}}
```

---

### C. Developer Mailing List – koha-devel
**Subscribe:** https://lists.koha-community.org/cgi-bin/mailman/listinfo/koha-devel
**Post to:** koha-devel@lists.koha-community.org

Send a brief introduction email with:
- Subject: `[RFC] Complaint and Glitch Management Module – Bug XXXXX`
- 3–4 sentences about the problem it solves
- Link to your Bugzilla ticket
- Link to your wiki RFC page

---

### D. Koha Community IRC / Matrix Chat (for quick feedback)
**Matrix:** https://matrix.to/#/#koha:matrix.org
**IRC:** irc.oftc.net → channel `#koha`

Introduce yourself and mention the bug number.

---

### E. General Contact
- **Website:** https://koha-community.org/contact/
- **Email:** info@koha-community.org
- **Support list:** koha@lists.katipo.co.nz

---

## 2. Step-by-Step Submission Workflow

```
Step 1 ── Create Bugzilla account  →  bugs.koha-community.org
Step 2 ── File enhancement ticket  →  note your BUG NUMBER
Step 3 ── Create wiki RFC page     →  wiki.koha-community.org
Step 4 ── Email koha-devel list    →  koha-devel@lists.koha-community.org
Step 5 ── Set up Git environment   →  git.koha-community.org
Step 6 ── Create feature branch    →  git checkout -b bug_XXXXX origin/main
Step 7 ── Add your code files      →  (see Section 3 below)
Step 8 ── Run tests                →  prove t/db_dependent/Koha/Complaints.t
Step 9 ── Submit patch via git     →  git send-email --to=patches@bugs.koha-community.org
Step 10 ─ Wait for QA / SO sign-off →  respond to reviewer comments
Step 11 ─ Release Manager merges   →  next Koha release
```

---

## 3. Files to Add to the Koha Source Tree

Place each file exactly at the path shown (relative to Koha root):

```
koha/
├── Koha/
│   ├── Complaint.pm                              ← ORM object class
│   └── Complaints.pm                             ← ORM result set class
├── cgi-bin/koha/
│   └── complaints.pl                             ← CGI controller
├── koha-tmpl/intranet-tmpl/prog/en/
│   └── modules/
│       └── complaints.tt                         ← Template Toolkit view
└── installer/data/mysql/
    ├── mandatory/complaints_schema.sql           ← Full schema (first install)
    └── db_revs/20251001000.pl                    ← DB upgrade entry
```

All files are provided in the `koha-integration/` folder of this repository.

---

## 4. Git Patch Submission Commands

```bash
# 1. Clone Koha source
git clone https://git.koha-community.org/Koha-community/Koha.git
cd Koha

# 2. Configure your identity
git config user.name  "Your Name"
git config user.email "your@email.com"

# 3. Create branch named after your bug number
git checkout -b bug_XXXXX origin/main

# 4. Copy your files into correct locations
cp /path/to/koha-integration/Koha/Complaint.pm   Koha/
cp /path/to/koha-integration/Koha/Complaints.pm  Koha/
cp /path/to/koha-integration/cgi-bin/koha/complaints.pl  cgi-bin/koha/
cp /path/to/koha-integration/koha-tmpl/...  koha-tmpl/...
cp /path/to/koha-integration/installer/...  installer/...

# 5. Stage and commit
git add Koha/Complaint.pm Koha/Complaints.pm \
        cgi-bin/koha/complaints.pl \
        koha-tmpl/intranet-tmpl/prog/en/modules/complaints.tt \
        installer/data/mysql/mandatory/complaints_schema.sql \
        installer/data/mysql/db_revs/20251001000.pl

git commit -m "Bug XXXXX: Add Complaint and Glitch Management Module

This patch introduces a dedicated complaint management module for
library staff. It allows patrons and staff to raise operational
glitches, assign them to the responsible team member, track
resolution status, and record prevention notes on patron records.

Files added:
  - Koha/Complaint.pm         (ORM object class)
  - Koha/Complaints.pm        (ORM result set)
  - cgi-bin/koha/complaints.pl (CGI controller)
  - koha-tmpl/.../complaints.tt (staff template)
  - installer/... sql + db_rev (schema & upgrade)

Signed-off-by: Your Name <your@email.com>"

# 6. Send patch to Bugzilla
git format-patch origin/main
git send-email --to=patches@bugs.koha-community.org *.patch
```

---

## 5. Koha Coding Standards to Follow

Before submission the Koha QA team will check:

| Requirement               | How to satisfy it                                      |
|---------------------------|--------------------------------------------------------|
| Perl::Critic              | Run `perlcritic --brutal Koha/Complaint.pm`            |
| Perltidy formatting       | Run `perltidy -pro=.perltidyrc Koha/Complaint.pm`      |
| Unit tests                | Add `t/db_dependent/Koha/Complaints.t`                 |
| CSRF tokens               | Use `[% INCLUDE 'csrf-token.inc' %]` in every form     |
| Signed-off-by             | Every commit must have `Signed-off-by: Name <email>`   |
| License header            | GNU GPL v3 header in every .pm and .pl file            |
| Template standards        | Use Koha breadcrumb, header, footer includes           |
| Coding guidelines         | wiki.koha-community.org/wiki/Coding_Guidelines         |

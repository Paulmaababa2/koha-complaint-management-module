# Code Audit Report — Koha Complaint Management Module

## Audit Summary

| Check                                  | Result |
|----------------------------------------|--------|
| Balanced braces (all 6 Perl files)     | PASS   |
| CSRF token in every form (5/5)         | PASS   |
| `cud-` prefix on all POST ops (5/5)   | PASS   |
| CSRF validation per `cud-` op (5/5)   | PASS   |
| No SQL comments in Perl db_rev         | PASS   |
| PRG redirect after every POST (5/5)   | PASS   |
| Correct sidebar include (tools-menu)   | PASS   |
| Translation support (i18n.inc)         | PASS   |
| Template path matches controller       | PASS   |
| SQL: 2 tables, 4 foreign keys          | PASS   |
| DBIx Schema files present              | PASS   |
| Unit tests: 5 subtests, 23 assertions  | PASS   |

---

## Bugs Fixed from Previous Version

### 1. CRITICAL — Missing DBIx Schema files
**Before:** No `Koha::Schema::Result::Complaint.pm` or `ComplaintComment.pm` existed.
**Impact:** The ORM would crash with `Can't find source 'Complaint'` — total module failure.
**Fix:** Added both Schema Result files with proper `__PACKAGE__->table()`, `add_columns()`, `set_primary_key()`, `belongs_to()`, `has_many()`, and `koha_object_class` / `koha_objects_class`.

### 2. CRITICAL — Wrong template path in controller
**Before:** `template_name => 'intranet/complaints.tt'`
**Fix:** `template_name => 'complaints/complaints.tt'` (Koha resolves from `modules/` automatically).

### 3. CRITICAL — No CSRF validation on POST operations
**Before:** All POST operations (`add_save`, `assign`, `resolve`, `close`) accepted without CSRF check.
**Impact:** Cross-site request forgery attack could create/modify/close complaints.
**Fix:** Every mutating operation now calls `output_and_exit_if_error($input, $cookie, $template, { check => 'csrf_token' })` before processing.

### 4. CRITICAL — Missing `cud-` prefix on mutating operations
**Before:** Operations named `add_save`, `assign`, `resolve`, `close`.
**Impact:** Koha >= 23.11 requires the `cud-` prefix for all state-changing operations; without it the CSRF framework rejects the request.
**Fix:** Renamed to `cud-add`, `cud-assign`, `cud-resolve`, `cud-close`, `cud-add_comment`.

### 5. CRITICAL — SQL comments in Perl db_rev file
**Before:** The `20251001000.pl` file started with `-- ============` SQL-style comments.
**Impact:** Perl syntax error — file would not load during database upgrade.
**Fix:** Rewritten as pure Perl with only `#` comments.

### 6. HIGH — Wrong `->new->search()` call pattern
**Before:** `Koha::Complaints->new->search(...)` used throughout.
**Impact:** Creates unnecessary empty object; does not match Koha conventions.
**Fix:** Changed to `Koha::Complaints->search(...)` (class method, as Koha uses).

### 7. HIGH — Wrong `flagsrequired` permission structure
**Before:** `flagsrequired => { complaints => 1 }` — `complaints` is not a top-level flag.
**Impact:** Permission check fails; no staff can access the module.
**Fix:** `flagsrequired => { tools => 'complaints' }` — sub-permission under the `tools` flag.

### 8. HIGH — Wrong sidebar include
**Before:** `[% INCLUDE 'admin-menu.inc' %]`
**Impact:** Shows administration menu instead of tools menu; confuses navigation.
**Fix:** `[% INCLUDE 'tools-menu.inc' %]`

### 9. HIGH — No Post-Redirect-Get (PRG) pattern
**Before:** After POST operations, the page re-rendered inline (re-submit on refresh).
**Impact:** Double-submission of complaints on browser refresh.
**Fix:** Every `cud-` operation now does `print $input->redirect(...)` then `exit`.

### 10. MEDIUM — Useless `complaints()` method in Complaint.pm
**Before:** `sub complaints` returned a search for itself by its own ID — circular and useless.
**Fix:** Replaced with meaningful relationship methods: `raiser()`, `assignee()`, `comments()`, `assign_to()`, `resolve()`, `close_ticket()`.

### 11. MEDIUM — Wrong method naming convention
**Before:** `search_by_status()`, `search_by_borrower()` — Koha uses `filter_by_*`.
**Fix:** Renamed to `filter_by_status()`, `filter_by_patron()`, `filter_by_assignee()`, `filter_by_open()`.

### 12. MEDIUM — No translation support in template
**Before:** All strings were hardcoded English.
**Fix:** Added `[% PROCESS 'i18n.inc' %]` and wrapped all user-visible strings in `[% t("...") | html %]`.

### 13. MEDIUM — Staff search used wrong bitmask
**Before:** `{ flags => { '&' => 1 } }` — bitwise AND with 1 (superlibrarian only).
**Fix:** `{ flags => { '>' => 0 } }` — any staff member with any permission.

### 14. LOW — No `store()` override for auto-timestamps and logging
**Before:** `store()` inherited from `Koha::Object` without customisation.
**Fix:** `Complaint.pm` now overrides `store()` to auto-set `created_on`, `updated_on`, and write to the action log.

---

## Final File Tree (9 files)

```
koha-integration/
├── Koha/
│   ├── Complaint.pm                 ← ORM object (196 lines)
│   ├── Complaints.pm                ← ORM result set (135 lines)
│   └── Schema/Result/
│       ├── Complaint.pm             ← DBIx schema (266 lines)
│       └── ComplaintComment.pm      ← DBIx schema (110 lines)
├── complaints/
│   └── complaints.pl                ← CGI controller (209 lines)
├── koha-tmpl/intranet-tmpl/prog/en/modules/complaints/
│   └── complaints.tt                ← Template Toolkit view (314 lines)
├── installer/data/mysql/
│   ├── mandatory/
│   │   └── complaints_schema.sql    ← Full DDL (92 lines)
│   └── db_revs/
│       └── 20251001000.pl           ← DB upgrade entry (89 lines)
└── t/db_dependent/Koha/
    └── Complaints.t                 ← Unit tests: 5 subtests, 23 assertions (214 lines)
```

## Where Each File Goes in Koha Source

| This repository file                    | Copy to (relative to Koha root)                                          |
|-----------------------------------------|---------------------------------------------------------------------------|
| `Koha/Complaint.pm`                     | `Koha/Complaint.pm`                                                      |
| `Koha/Complaints.pm`                    | `Koha/Complaints.pm`                                                     |
| `Koha/Schema/Result/Complaint.pm`       | `Koha/Schema/Result/Complaint.pm`                                        |
| `Koha/Schema/Result/ComplaintComment.pm`| `Koha/Schema/Result/ComplaintComment.pm`                                 |
| `complaints/complaints.pl`              | `complaints/complaints.pl`                                               |
| `koha-tmpl/.../complaints/complaints.tt`| `koha-tmpl/intranet-tmpl/prog/en/modules/complaints/complaints.tt`       |
| `installer/.../complaints_schema.sql`   | `installer/data/mysql/mandatory/complaints_schema.sql`                   |
| `installer/.../20251001000.pl`          | `installer/data/mysql/db_revs/20251001000.pl`                            |
| `t/.../Complaints.t`                    | `t/db_dependent/Koha/Complaints.t`                                       |

#!/usr/bin/perl

# Copyright 2025 [Your Name / Institution]
#
# This file is part of Koha.
#
# Koha is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# Koha is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Koha; if not, see <https://www.gnu.org/licenses>.

use Modern::Perl;
use CGI qw( -utf8 );
use C4::Auth   qw( get_template_and_user );
use C4::Output qw( output_html_with_http_headers output_and_exit_if_error );
use Koha::Complaints;
use Koha::Complaint;
use Koha::Patrons;
use Koha::DateUtils qw( dt_from_string );

my $input        = CGI->new;
my $op           = $input->param('op')           // 'list';
my $complaint_id = $input->param('complaint_id') // 0;

# ------------------------------------------------------------------
# Authentication — uses tools > complaints sub-permission
# ------------------------------------------------------------------
my ( $template, $loggedinuser, $cookie ) = get_template_and_user(
    {
        template_name   => "complaints/complaints.tt",
        query           => $input,
        type            => "intranet",
        flagsrequired   => { tools => 'complaints' },
    }
);

# ------------------------------------------------------------------
# Mutating operations (all prefixed cud- per Koha CSRF convention)
# ------------------------------------------------------------------
if ( $op eq 'cud-add' ) {

    # Validate CSRF token first
    output_and_exit_if_error( $input, $cookie, $template, { check => 'csrf_token' } );

    my $title       = $input->param('title')       // '';
    my $category    = $input->param('category')    // 'other';
    my $priority    = $input->param('priority')    // 'medium';
    my $description = $input->param('description') // '';
    my $location    = $input->param('location')    // '';

    Koha::Complaint->new(
        {
            borrowernumber => $loggedinuser,
            title          => $title,
            category       => $category,
            priority       => $priority,
            description    => $description,
            location       => $location,
        }
    )->store;

    print $input->redirect("/cgi-bin/koha/complaints/complaints.pl?op=list&saved=1");
    exit;

} elsif ( $op eq 'cud-assign' ) {

    output_and_exit_if_error( $input, $cookie, $template, { check => 'csrf_token' } );

    my $assignee = $input->param('assignee_borrowernumber');
    my $complaint = Koha::Complaints->find($complaint_id);

    if ($complaint) {
        $complaint->assign_to($assignee);
    }

    print $input->redirect("/cgi-bin/koha/complaints/complaints.pl?op=list");
    exit;

} elsif ( $op eq 'cud-resolve' ) {

    output_and_exit_if_error( $input, $cookie, $template, { check => 'csrf_token' } );

    my $resolution = $input->param('resolution') // '';
    my $complaint  = Koha::Complaints->find($complaint_id);

    if ($complaint) {
        $complaint->resolve( { resolution => $resolution } );
    }

    print $input->redirect("/cgi-bin/koha/complaints/complaints.pl?op=list");
    exit;

} elsif ( $op eq 'cud-close' ) {

    output_and_exit_if_error( $input, $cookie, $template, { check => 'csrf_token' } );

    my $complaint = Koha::Complaints->find($complaint_id);

    if ($complaint) {
        $complaint->close_ticket;
    }

    print $input->redirect("/cgi-bin/koha/complaints/complaints.pl?op=list");
    exit;

} elsif ( $op eq 'cud-add_comment' ) {

    output_and_exit_if_error( $input, $cookie, $template, { check => 'csrf_token' } );

    my $comment_text = $input->param('comment') // '';
    if ( $complaint_id && $comment_text ) {
        my $schema = Koha::Database->new->schema;
        $schema->resultset('ComplaintComment')->create(
            {
                complaint_id   => $complaint_id,
                borrowernumber => $loggedinuser,
                comment        => $comment_text,
                created_on     => dt_from_string(),
            }
        );
    }

    print $input->redirect("/cgi-bin/koha/complaints/complaints.pl?op=view&complaint_id=$complaint_id");
    exit;
}

# ------------------------------------------------------------------
# Read-only operations
# ------------------------------------------------------------------
if ( $op eq 'add_form' ) {

    $template->param( op => 'add_form' );

} elsif ( $op eq 'view' ) {

    my $complaint = Koha::Complaints->find($complaint_id);

    if ($complaint) {
        my @comments = $complaint->comments->search(
            {},
            { order_by => { -asc => 'created_on' } }
        )->as_list;

        $template->param(
            op        => 'view',
            complaint => $complaint,
            comments  => \@comments,
        );
    } else {
        $template->param(
            op        => 'list',
            error_msg => 'Complaint not found.',
        );
        $op = 'list';    # fall through
    }

} else {
    $op = 'list';
}

# ------------------------------------------------------------------
# Default: complaint list
# ------------------------------------------------------------------
if ( $op eq 'list' ) {

    my $status_filter = $input->param('status') // '';

    my $search_params = {};
    $search_params->{status} = $status_filter if $status_filter;

    my @complaints = Koha::Complaints->search_limited(
        $search_params,
        { order_by => { -desc => 'created_on' } }
    )->as_list;

    # Staff members for the assign dropdown
    my @staff = Koha::Patrons->search(
        { flags => { '>' => 0 } },
        { order_by => [qw( surname firstname )] }
    )->as_list;

    # Counts per status for filter tabs
    my $open_count     = Koha::Complaints->search( { status => 'open' } )->count;
    my $progress_count = Koha::Complaints->search( { status => 'in_progress' } )->count;
    my $resolved_count = Koha::Complaints->search( { status => 'resolved' } )->count;
    my $closed_count   = Koha::Complaints->search( { status => 'closed' } )->count;

    $template->param(
        op             => 'list',
        complaints     => \@complaints,
        staff_list     => \@staff,
        status_filter  => $status_filter,
        open_count     => $open_count,
        progress_count => $progress_count,
        resolved_count => $resolved_count,
        closed_count   => $closed_count,
        saved          => scalar $input->param('saved'),
    );
}

output_html_with_http_headers $input, $cookie, $template->output;

#!/usr/bin/perl

# Copyright 2025 [Your Name / Institution]
#
# This file is part of Koha.
#
# Koha is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# Koha is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Koha; if not, see <https://www.gnu.org/licenses>.

=head1 NAME

t/db_dependent/Koha/Complaints.t

=head1 DESCRIPTION

Unit tests for Koha::Complaint and Koha::Complaints.

=cut

use Modern::Perl;
use Test::More tests => 5;
use Test::Exception;

use C4::Context;
use Koha::Database;
use Koha::Complaints;
use Koha::Complaint;
use Koha::DateUtils qw( dt_from_string );

use t::lib::TestBuilder;
use t::lib::Mocks;

my $schema  = Koha::Database->new->schema;
my $builder = t::lib::TestBuilder->new;

# All tests inside a transaction so the DB stays clean
$schema->storage->txn_begin;

# ---------------------------------------------------------------
subtest 'Basic CRUD' => sub {
    plan tests => 8;

    my $patron = $builder->build_object( { class => 'Koha::Patrons' } );

    # Create
    my $complaint = Koha::Complaint->new(
        {
            borrowernumber => $patron->borrowernumber,
            title          => 'OPAC search broken',
            category       => 'catalogue',
            priority       => 'high',
            description    => 'The search page returns 500 error.',
        }
    )->store;

    ok( $complaint->complaint_id, 'Complaint created with auto-increment ID' );
    is( $complaint->status, 'open', 'Default status is "open"' );
    ok( $complaint->created_on, 'created_on auto-populated by store()' );
    ok( $complaint->updated_on, 'updated_on auto-populated by store()' );

    # Read
    my $fetched = Koha::Complaints->find( $complaint->complaint_id );
    is( $fetched->title, 'OPAC search broken', 'Title matches after re-fetch' );

    # Update
    $fetched->priority('critical');
    $fetched->store;
    my $refetched = Koha::Complaints->find( $fetched->complaint_id );
    is( $refetched->priority, 'critical', 'Priority updated correctly' );

    # Delete
    $refetched->delete;
    my $gone = Koha::Complaints->find( $refetched->complaint_id );
    is( $gone, undef, 'Complaint deleted successfully' );

    # Count
    my $count_before = Koha::Complaints->search->count;
    Koha::Complaint->new(
        {
            borrowernumber => $patron->borrowernumber,
            title          => 'Test count',
            description    => 'x',
        }
    )->store;
    is( Koha::Complaints->search->count, $count_before + 1, 'Count incremented' );
};

# ---------------------------------------------------------------
subtest 'Relationship methods (raiser, assignee)' => sub {
    plan tests => 4;

    my $patron = $builder->build_object( { class => 'Koha::Patrons' } );
    my $staff  = $builder->build_object( { class => 'Koha::Patrons' } );

    my $complaint = Koha::Complaint->new(
        {
            borrowernumber          => $patron->borrowernumber,
            assignee_borrowernumber => $staff->borrowernumber,
            title                   => 'FK test',
            description             => 'Testing relationships',
        }
    )->store;

    my $raiser = $complaint->raiser;
    ok( $raiser, 'raiser() returns a patron' );
    is( $raiser->borrowernumber, $patron->borrowernumber, 'raiser is correct patron' );

    my $assignee = $complaint->assignee;
    ok( $assignee, 'assignee() returns a patron' );
    is( $assignee->borrowernumber, $staff->borrowernumber, 'assignee is correct staff' );
};

# ---------------------------------------------------------------
subtest 'Workflow helpers (assign_to, resolve, close_ticket)' => sub {
    plan tests => 6;

    my $patron = $builder->build_object( { class => 'Koha::Patrons' } );
    my $staff  = $builder->build_object( { class => 'Koha::Patrons' } );

    my $c = Koha::Complaint->new(
        {
            borrowernumber => $patron->borrowernumber,
            title          => 'Workflow test',
            description    => 'Step through statuses',
        }
    )->store;

    is( $c->status, 'open', 'Starts as open' );

    # assign_to
    $c->assign_to( $staff->borrowernumber );
    is( $c->status, 'in_progress', 'After assign_to: in_progress' );
    is( $c->assignee_borrowernumber, $staff->borrowernumber, 'Assignee set' );

    # resolve
    $c->resolve( { resolution => 'Fixed the query.' } );
    is( $c->status, 'resolved', 'After resolve: resolved' );
    ok( $c->resolved_on, 'resolved_on timestamp set' );

    # close_ticket
    $c->close_ticket;
    is( $c->status, 'closed', 'After close_ticket: closed' );
};

# ---------------------------------------------------------------
subtest 'filter_by helpers' => sub {
    plan tests => 3;

    my $patron = $builder->build_object( { class => 'Koha::Patrons' } );

    # Create two complaints with different statuses
    my $c1 = Koha::Complaint->new(
        {
            borrowernumber => $patron->borrowernumber,
            title          => 'Filter A',
            description    => 'open one',
        }
    )->store;

    my $c2 = Koha::Complaint->new(
        {
            borrowernumber => $patron->borrowernumber,
            title          => 'Filter B',
            description    => 'will be resolved',
        }
    )->store;
    $c2->resolve( { resolution => 'done' } );

    ok(
        Koha::Complaints->search->filter_by_status('open')->count >= 1,
        'filter_by_status("open") returns at least one'
    );
    ok(
        Koha::Complaints->search->filter_by_status('resolved')->count >= 1,
        'filter_by_status("resolved") returns at least one'
    );
    ok(
        Koha::Complaints->search->filter_by_patron( $patron->borrowernumber )->count >= 2,
        'filter_by_patron returns this patron s complaints'
    );
};

# ---------------------------------------------------------------
subtest 'to_api_mapping' => sub {
    plan tests => 2;

    my $patron = $builder->build_object( { class => 'Koha::Patrons' } );
    my $c = Koha::Complaint->new(
        {
            borrowernumber => $patron->borrowernumber,
            title          => 'API map test',
            description    => 'x',
        }
    )->store;

    my $map = $c->to_api_mapping;
    is( ref $map, 'HASH', 'to_api_mapping returns a hashref' );
    is( $map->{borrowernumber}, 'patron_id', 'borrowernumber mapped to patron_id' );
};

# ---------------------------------------------------------------
$schema->storage->txn_rollback;

done_testing();

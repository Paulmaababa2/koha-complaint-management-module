use utf8;
package Koha::Schema::Result::ComplaintComment;

# This file is part of Koha.
#
# Koha is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# Koha is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Koha; if not, see <https://www.gnu.org/licenses>.

=head1 NAME

Koha::Schema::Result::ComplaintComment

=cut

use strict;
use warnings;

use base 'DBIx::Class::Core';

=head1 TABLE: C<complaint_comments>

=cut

__PACKAGE__->table("complaint_comments");

=head1 ACCESSORS

=head2 comment_id

  data_type: 'integer'
  is_auto_increment: 1
  is_nullable: 0

=head2 complaint_id

  data_type: 'integer'
  is_foreign_key: 1
  is_nullable: 0

=head2 borrowernumber

  data_type: 'integer'
  is_foreign_key: 1
  is_nullable: 0

=head2 comment

  data_type: 'longtext'
  is_nullable: 0

=head2 created_on

  data_type: 'datetime'
  datetime_undef_if_invalid: 1
  is_nullable: 0

=cut

__PACKAGE__->add_columns(
    "comment_id",
    { data_type => "integer", is_auto_increment => 1, is_nullable => 0 },
    "complaint_id",
    { data_type => "integer", is_foreign_key => 1, is_nullable => 0 },
    "borrowernumber",
    { data_type => "integer", is_foreign_key => 1, is_nullable => 0 },
    "comment",
    { data_type => "longtext", is_nullable => 0 },
    "created_on",
    {
        data_type                 => "datetime",
        datetime_undef_if_invalid => 1,
        is_nullable               => 0,
    },
);

__PACKAGE__->set_primary_key("comment_id");

__PACKAGE__->belongs_to(
    "complaint",
    "Koha::Schema::Result::Complaint",
    { "foreign.complaint_id" => "self.complaint_id" },
    { is_deferrable => 1, on_delete => "CASCADE", on_update => "CASCADE" },
);

__PACKAGE__->belongs_to(
    "borrower",
    "Koha::Schema::Result::Borrower",
    { "foreign.borrowernumber" => "self.borrowernumber" },
    { is_deferrable => 1, on_delete => "CASCADE", on_update => "CASCADE" },
);

sub koha_object_class {
    'Koha::Complaint::Comment';
}

sub koha_objects_class {
    'Koha::Complaint::Comments';
}

1;

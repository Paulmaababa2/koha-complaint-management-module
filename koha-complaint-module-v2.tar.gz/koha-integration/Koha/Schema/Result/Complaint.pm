use utf8;
package Koha::Schema::Result::Complaint;

# This file is part of Koha.
#
# Koha is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# Koha is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Koha; if not, see <https://www.gnu.org/licenses>.

=head1 NAME

Koha::Schema::Result::Complaint

=cut

use strict;
use warnings;

use base 'DBIx::Class::Core';

=head1 TABLE: C<complaints>

=cut

__PACKAGE__->table("complaints");

=head1 ACCESSORS

=head2 complaint_id

  data_type: 'integer'
  is_auto_increment: 1
  is_nullable: 0

unique identifier for the complaint ticket

=head2 borrowernumber

  data_type: 'integer'
  is_foreign_key: 1
  is_nullable: 0

FK to borrowers.borrowernumber — patron or staff who raised the complaint

=head2 assignee_borrowernumber

  data_type: 'integer'
  is_foreign_key: 1
  is_nullable: 1

FK to borrowers.borrowernumber — staff member assigned to resolve

=head2 title

  data_type: 'varchar'
  is_nullable: 0
  size: 200

short summary of the complaint

=head2 category

  data_type: 'varchar'
  is_nullable: 0
  default_value: 'other'
  size: 50

module area: catalogue, circulation, acquisitions, reports, system, other

=head2 priority

  data_type: 'varchar'
  is_nullable: 0
  default_value: 'medium'
  size: 20

urgency level: critical, high, medium, low

=head2 description

  data_type: 'longtext'
  is_nullable: 0

full description of the issue

=head2 location

  data_type: 'varchar'
  is_nullable: 1
  size: 200

page or module where the glitch occurred

=head2 status

  data_type: 'varchar'
  is_nullable: 0
  default_value: 'open'
  size: 20

workflow state: open, in_progress, resolved, closed

=head2 resolution

  data_type: 'longtext'
  is_nullable: 1

staff resolution note

=head2 patron_remarks

  data_type: 'longtext'
  is_nullable: 1

future-prevention notes (visible on patron record)

=head2 created_on

  data_type: 'datetime'
  datetime_undef_if_invalid: 1
  is_nullable: 0

=head2 updated_on

  data_type: 'datetime'
  datetime_undef_if_invalid: 1
  is_nullable: 1

=head2 resolved_on

  data_type: 'datetime'
  datetime_undef_if_invalid: 1
  is_nullable: 1

=cut

__PACKAGE__->add_columns(
    "complaint_id",
    { data_type => "integer", is_auto_increment => 1, is_nullable => 0 },
    "borrowernumber",
    { data_type => "integer", is_foreign_key => 1, is_nullable => 0 },
    "assignee_borrowernumber",
    { data_type => "integer", is_foreign_key => 1, is_nullable => 1 },
    "title",
    { data_type => "varchar", is_nullable => 0, size => 200 },
    "category",
    { data_type => "varchar", default_value => "other", is_nullable => 0, size => 50 },
    "priority",
    { data_type => "varchar", default_value => "medium", is_nullable => 0, size => 20 },
    "description",
    { data_type => "longtext", is_nullable => 0 },
    "location",
    { data_type => "varchar", is_nullable => 1, size => 200 },
    "status",
    { data_type => "varchar", default_value => "open", is_nullable => 0, size => 20 },
    "resolution",
    { data_type => "longtext", is_nullable => 1 },
    "patron_remarks",
    { data_type => "longtext", is_nullable => 1 },
    "created_on",
    {
        data_type                 => "datetime",
        datetime_undef_if_invalid => 1,
        is_nullable               => 0,
    },
    "updated_on",
    {
        data_type                 => "datetime",
        datetime_undef_if_invalid => 1,
        is_nullable               => 1,
    },
    "resolved_on",
    {
        data_type                 => "datetime",
        datetime_undef_if_invalid => 1,
        is_nullable               => 1,
    },
);

=head1 PRIMARY KEY

=over 4

=item * L</complaint_id>

=back

=cut

__PACKAGE__->set_primary_key("complaint_id");

=head1 RELATIONS

=head2 raiser

Type: belongs_to

Related object: L<Koha::Schema::Result::Borrower>

=cut

__PACKAGE__->belongs_to(
    "raiser",
    "Koha::Schema::Result::Borrower",
    { "foreign.borrowernumber" => "self.borrowernumber" },
    {
        is_deferrable => 1,
        join_type     => "LEFT",
        on_delete     => "CASCADE",
        on_update     => "CASCADE",
    },
);

=head2 assignee

Type: belongs_to

Related object: L<Koha::Schema::Result::Borrower>

=cut

__PACKAGE__->belongs_to(
    "assignee",
    "Koha::Schema::Result::Borrower",
    { "foreign.borrowernumber" => "self.assignee_borrowernumber" },
    {
        is_deferrable => 1,
        join_type     => "LEFT",
        on_delete     => "SET NULL",
        on_update     => "CASCADE",
    },
);

=head2 complaint_comments

Type: has_many

Related object: L<Koha::Schema::Result::ComplaintComment>

=cut

__PACKAGE__->has_many(
    "complaint_comments",
    "Koha::Schema::Result::ComplaintComment",
    { "foreign.complaint_id" => "self.complaint_id" },
    { cascade_copy => 0, cascade_delete => 1 },
);

sub koha_objects_class {
    'Koha::Complaints';
}

sub koha_object_class {
    'Koha::Complaint';
}

1;

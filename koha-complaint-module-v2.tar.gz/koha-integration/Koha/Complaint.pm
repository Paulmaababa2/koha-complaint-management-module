package Koha::Complaint;

# Copyright 2025 [Your Name / Institution]
#
# This file is part of Koha.
#
# Koha is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# Koha is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Koha; if not, see <https://www.gnu.org/licenses>.

use Modern::Perl;

use C4::Context;
use C4::Log qw( logaction );
use Koha::Database;
use Koha::DateUtils qw( dt_from_string );
use Koha::Patrons;

use base qw(Koha::Object);

=head1 NAME

Koha::Complaint - Koha Complaint object class

=head1 API

=head2 Class methods

=head3 store

Override default store to auto-set created_on for new records and
updated_on for existing records, and to write an action log entry.

=cut

sub store {
    my ($self) = @_;

    my $is_new = !$self->in_storage;

    if ($is_new) {
        $self->created_on( dt_from_string() ) unless $self->created_on;
        $self->status('open')                 unless $self->status;
    }

    $self->updated_on( dt_from_string() );

    my $result = $self->SUPER::store();

    if ( C4::Context->preference('ComplaintManagement') ) {
        my $action = $is_new ? 'CREATE' : 'MODIFY';
        logaction( 'COMPLAINTS', $action, $result->complaint_id );
    }

    return $result;
}

=head3 raiser

    my $patron = $complaint->raiser;

Returns the L<Koha::Patron> who raised this complaint.

=cut

sub raiser {
    my ($self) = @_;
    my $raiser_rs = $self->_result->raiser;
    return unless $raiser_rs;
    return Koha::Patron->_new_from_dbic($raiser_rs);
}

=head3 assignee

    my $staff = $complaint->assignee;

Returns the L<Koha::Patron> (staff member) assigned to resolve this complaint.

=cut

sub assignee {
    my ($self) = @_;
    my $assignee_rs = $self->_result->assignee;
    return unless $assignee_rs;
    return Koha::Patron->_new_from_dbic($assignee_rs);
}

=head3 comments

    my $comments = $complaint->comments;

Returns the related L<Koha::Complaint::Comments> result set.

=cut

sub comments {
    my ($self) = @_;
    my $comments_rs = $self->_result->complaint_comments;
    return Koha::Complaint::Comments->_new_from_dbic($comments_rs);
}

=head3 assign_to

    $complaint->assign_to($borrowernumber);

Assigns the complaint to the given staff member and sets status to
C<in_progress>.

=cut

sub assign_to {
    my ( $self, $borrowernumber ) = @_;

    $self->assignee_borrowernumber($borrowernumber);
    $self->status('in_progress');
    return $self->store;
}

=head3 resolve

    $complaint->resolve({ resolution => $text });

Marks the complaint as resolved and stores the resolution note.

=cut

sub resolve {
    my ( $self, $params ) = @_;

    $self->resolution( $params->{resolution} ) if $params->{resolution};
    $self->status('resolved');
    $self->resolved_on( dt_from_string() );
    return $self->store;
}

=head3 close_ticket

    $complaint->close_ticket;

Sets status to C<closed>. Separate from C<close> to avoid clashing
with Perl's built-in C<CORE::close>.

=cut

sub close_ticket {
    my ($self) = @_;

    $self->status('closed');
    return $self->store;
}

=head3 to_api_mapping

Mapping of DB column names to API field names for the REST API.

=cut

sub to_api_mapping {
    return {
        complaint_id            => 'complaint_id',
        borrowernumber          => 'patron_id',
        assignee_borrowernumber => 'assignee_id',
        title                   => 'title',
        category                => 'category',
        priority                => 'priority',
        description             => 'description',
        location                => 'location',
        status                  => 'status',
        resolution              => 'resolution',
        patron_remarks          => 'patron_remarks',
        created_on              => 'created_date',
        updated_on              => 'updated_date',
        resolved_on             => 'resolved_date',
    };
}

=head2 Internal methods

=head3 _type

=cut

sub _type {
    return 'Complaint';
}

1;

package Koha::Complaints;

# Copyright 2025 [Your Name / Institution]
#
# This file is part of Koha.
#
# Koha is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# Koha is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Koha; if not, see <https://www.gnu.org/licenses>.

use Modern::Perl;

use C4::Context;
use Koha::Database;
use Koha::Complaint;

use base qw(Koha::Objects);

=head1 NAME

Koha::Complaints - Koha Complaints object set class

=head1 API

=head2 Class methods

=head3 filter_by_open

    my $open = Koha::Complaints->search->filter_by_open;

Returns a resultset of complaints that are open or in progress.

=cut

sub filter_by_open {
    my ($self) = @_;
    return $self->search( { status => [ 'open', 'in_progress' ] } );
}

=head3 filter_by_status

    my $resolved = Koha::Complaints->search->filter_by_status('resolved');

Returns a resultset filtered to the given status value.

=cut

sub filter_by_status {
    my ( $self, $status ) = @_;
    return $self->search( { status => $status } );
}

=head3 filter_by_patron

    my $mine = Koha::Complaints->search->filter_by_patron($borrowernumber);

Returns complaints raised by the given patron.

=cut

sub filter_by_patron {
    my ( $self, $borrowernumber ) = @_;
    return $self->search( { borrowernumber => $borrowernumber } );
}

=head3 filter_by_assignee

    my $assigned = Koha::Complaints->search->filter_by_assignee($borrowernumber);

Returns complaints assigned to the given staff member.

=cut

sub filter_by_assignee {
    my ( $self, $borrowernumber ) = @_;
    return $self->search( { assignee_borrowernumber => $borrowernumber } );
}

=head3 search_limited

    my $complaints = Koha::Complaints->search_limited( $params, $attrs );

Respects IndependentBranches: non-superlibrarians see only their own
branch's complaints (via the raiser's branchcode).

=cut

sub search_limited {
    my ( $self, $params, $attributes ) = @_;

    my $resultset = $self;

    if (   C4::Context->preference('IndependentBranches')
        && !C4::Context->IsSuperLibrarian() )
    {
        my $userenv = C4::Context->userenv;
        if ( $userenv && $userenv->{branch} ) {
            $attributes //= {};
            $attributes->{join} //= [];
            push @{ $attributes->{join} }, 'raiser';
            $params->{'raiser.branchcode'} = $userenv->{branch};
        }
    }

    return $resultset->search( $params, $attributes );
}

=head2 Internal methods

=head3 _type

=cut

sub _type {
    return 'Complaint';
}

=head3 object_class

=cut

sub object_class {
    return 'Koha::Complaint';
}

1;

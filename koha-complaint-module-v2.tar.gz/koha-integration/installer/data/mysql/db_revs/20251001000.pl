use Modern::Perl;

return {
    bug_number  => "XXXXX",    # ← replace with your Bugzilla number
    description => "Add Complaint and Glitch Management module tables and permission",
    up          => sub {
        my ($args) = @_;
        my ( $dbh, $out ) = @{$args}{qw( dbh out )};

        # --- Table: complaints -------------------------------------------
        unless ( TableExists('complaints') ) {
            $dbh->do(q{
                CREATE TABLE `complaints` (
                    `complaint_id`             int(11)      NOT NULL AUTO_INCREMENT,
                    `borrowernumber`           int(11)      NOT NULL,
                    `assignee_borrowernumber`  int(11)      DEFAULT NULL,
                    `title`                    varchar(200) NOT NULL,
                    `category`                 varchar(50)  NOT NULL DEFAULT 'other',
                    `priority`                 varchar(20)  NOT NULL DEFAULT 'medium',
                    `description`              longtext     NOT NULL,
                    `location`                 varchar(200) DEFAULT NULL,
                    `status`                   varchar(20)  NOT NULL DEFAULT 'open',
                    `resolution`               longtext     DEFAULT NULL,
                    `patron_remarks`           longtext     DEFAULT NULL,
                    `created_on`               datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_on`               datetime     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                    `resolved_on`              datetime     DEFAULT NULL,
                    PRIMARY KEY (`complaint_id`),
                    KEY `idx_complaints_borrower`  (`borrowernumber`),
                    KEY `idx_complaints_assignee`  (`assignee_borrowernumber`),
                    KEY `idx_complaints_status`    (`status`),
                    KEY `idx_complaints_created`   (`created_on`),
                    CONSTRAINT `complaints_fk_borrower` FOREIGN KEY (`borrowernumber`)
                        REFERENCES `borrowers` (`borrowernumber`)
                        ON DELETE CASCADE ON UPDATE CASCADE,
                    CONSTRAINT `complaints_fk_assignee` FOREIGN KEY (`assignee_borrowernumber`)
                        REFERENCES `borrowers` (`borrowernumber`)
                        ON DELETE SET NULL ON UPDATE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            });
            say $out "Added table 'complaints'";
        }

        # --- Table: complaint_comments -----------------------------------
        unless ( TableExists('complaint_comments') ) {
            $dbh->do(q{
                CREATE TABLE `complaint_comments` (
                    `comment_id`     int(11)  NOT NULL AUTO_INCREMENT,
                    `complaint_id`   int(11)  NOT NULL,
                    `borrowernumber` int(11)  NOT NULL,
                    `comment`        longtext NOT NULL,
                    `created_on`     datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (`comment_id`),
                    KEY `idx_cc_complaint` (`complaint_id`),
                    KEY `idx_cc_borrower`  (`borrowernumber`),
                    CONSTRAINT `cc_fk_complaint` FOREIGN KEY (`complaint_id`)
                        REFERENCES `complaints` (`complaint_id`)
                        ON DELETE CASCADE ON UPDATE CASCADE,
                    CONSTRAINT `cc_fk_borrower` FOREIGN KEY (`borrowernumber`)
                        REFERENCES `borrowers` (`borrowernumber`)
                        ON DELETE CASCADE ON UPDATE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            });
            say $out "Added table 'complaint_comments'";
        }

        # --- Sub-permission under tools ----------------------------------
        $dbh->do(q{
            INSERT IGNORE INTO `permissions` (`module_bit`, `code`, `description`)
            VALUES (
                13,
                'complaints',
                'Manage complaint and glitch tickets (raise, assign, resolve, close)'
            )
        });
        say $out "Added permission tools > complaints";

        # --- System preference -------------------------------------------
        $dbh->do(q{
            INSERT IGNORE INTO `systempreferences`
                (`variable`, `value`, `options`, `explanation`, `type`)
            VALUES
                ('ComplaintManagement', '1', '1|0',
                 'If enabled, the Complaint and Glitch Management module is available under Tools.',
                 'YesNo')
        });
        say $out "Added system preference ComplaintManagement";
    },
};

-- ============================================================
-- Koha Complaint Management Module — Database Schema
-- MySQL / MariaDB
-- ============================================================

-- -----------------------------------------------------------
-- Table: complaints
-- -----------------------------------------------------------
DROP TABLE IF EXISTS `complaint_comments`;
DROP TABLE IF EXISTS `complaints`;

CREATE TABLE `complaints` (
    `complaint_id`             int(11)      NOT NULL AUTO_INCREMENT,
    `borrowernumber`           int(11)      NOT NULL
        COMMENT 'FK → borrowers.borrowernumber — who raised',
    `assignee_borrowernumber`  int(11)      DEFAULT NULL
        COMMENT 'FK → borrowers.borrowernumber — assigned staff',
    `title`                    varchar(200) NOT NULL,
    `category`                 varchar(50)  NOT NULL DEFAULT 'other'
        COMMENT 'catalogue|circulation|acquisitions|serials|reports|system|other',
    `priority`                 varchar(20)  NOT NULL DEFAULT 'medium'
        COMMENT 'critical|high|medium|low',
    `description`              longtext     NOT NULL,
    `location`                 varchar(200) DEFAULT NULL
        COMMENT 'page / module where the glitch occurred',
    `status`                   varchar(20)  NOT NULL DEFAULT 'open'
        COMMENT 'open|in_progress|resolved|closed',
    `resolution`               longtext     DEFAULT NULL
        COMMENT 'staff resolution note',
    `patron_remarks`           longtext     DEFAULT NULL
        COMMENT 'prevention notes visible on patron record',
    `created_on`               datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_on`               datetime     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    `resolved_on`              datetime     DEFAULT NULL,
    PRIMARY KEY (`complaint_id`),
    KEY `idx_complaints_borrower`  (`borrowernumber`),
    KEY `idx_complaints_assignee`  (`assignee_borrowernumber`),
    KEY `idx_complaints_status`    (`status`),
    KEY `idx_complaints_created`   (`created_on`),
    CONSTRAINT `complaints_fk_borrower` FOREIGN KEY (`borrowernumber`)
        REFERENCES `borrowers` (`borrowernumber`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `complaints_fk_assignee` FOREIGN KEY (`assignee_borrowernumber`)
        REFERENCES `borrowers` (`borrowernumber`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------
-- Table: complaint_comments
-- -----------------------------------------------------------
CREATE TABLE `complaint_comments` (
    `comment_id`     int(11)  NOT NULL AUTO_INCREMENT,
    `complaint_id`   int(11)  NOT NULL,
    `borrowernumber` int(11)  NOT NULL,
    `comment`        longtext NOT NULL,
    `created_on`     datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`comment_id`),
    KEY `idx_cc_complaint` (`complaint_id`),
    KEY `idx_cc_borrower`  (`borrowernumber`),
    CONSTRAINT `cc_fk_complaint` FOREIGN KEY (`complaint_id`)
        REFERENCES `complaints` (`complaint_id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `cc_fk_borrower` FOREIGN KEY (`borrowernumber`)
        REFERENCES `borrowers` (`borrowernumber`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------
-- Permission: add 'complaints' sub-permission under 'tools'
-- (Koha 23.11+ stores sub-permissions in the permissions table)
-- -----------------------------------------------------------
INSERT IGNORE INTO `permissions` (`module_bit`, `code`, `description`)
VALUES (
    13,
    'complaints',
    'Manage complaint and glitch tickets (raise, assign, resolve, close)'
);
-- NOTE: module_bit 13 = 'tools' in Koha's userflags table.
-- Verify with:  SELECT bit FROM userflags WHERE flag = 'tools';


-- -----------------------------------------------------------
-- System preference: toggle module on/off
-- -----------------------------------------------------------
INSERT IGNORE INTO `systempreferences`
    (`variable`, `value`, `options`, `explanation`, `type`)
VALUES
    ('ComplaintManagement', '1', '1|0',
     'If enabled, the Complaint and Glitch Management module is available under Tools.',
     'YesNo');
